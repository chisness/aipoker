java -cp dist/pokerserver.jar ca.ualberta.cs.poker.free.alien.GraphicalAlienClient graphicalalienclientnolimit2007.prf
