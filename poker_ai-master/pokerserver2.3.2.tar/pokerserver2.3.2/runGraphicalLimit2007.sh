java -cp dist/pokerserver.jar ca.ualberta.cs.poker.free.alien.GraphicalAlienClient graphicalalienclientlimit2007.prf
