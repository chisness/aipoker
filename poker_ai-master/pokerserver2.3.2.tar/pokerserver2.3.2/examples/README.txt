This directory contains three examples of possible submissions (randomclient and academy25client and nolimitrandomclient) and a server.

To make these work, go to the parent directory and run compile.bat.

Then, use run.bat or runNoLimit.bat.


To make your own bot, you write a startme.bat file such that:

startme.bat 123.41.45.1  4123

Will start your bot and connect it to the server. Then, you tar or jar all relevant
files, remembering which directory startme.bat is in your zipped file.


For how to run your own bots, see the README.txt in the parent directory.