java -cp dist/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge linuxlocal.prf generateCards
java -cp dist/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge linuxlocal.prf runTournament
