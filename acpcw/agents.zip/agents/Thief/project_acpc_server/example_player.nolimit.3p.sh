#!/bin/bash
./example_player holdem.nolimit.3p.game $1 $2
