#!/bin/bash
./example_player holdem.nolimit.6p.game $1 $2
