#!/bin/bash
/usr/bin/python2.7 ./kuhn3p-master/connect_to_dealer.py $1 $2
