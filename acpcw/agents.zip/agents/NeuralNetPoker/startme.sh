#!/bin/sh
python3.5 player.py $1 $2
