#!/bin/bash
/usr/bin/python2.7 connect_to_dealer.py $1 $2
