My name is Michael Weiland and this is my submission for the class project.
I worked independantly without a group.
The code I wrote for my poker player is in the kuhn3p-master/Special.py file.  