/* Carlos Lores
   Jorge Cura
   CAP 4630 U01 Artificial Intelligence - Fall 2017
   Final Project - 3 Player Kuhn Poker
*/

to run:

from a command shell do: "$Agent IP Port"
	where 'IP' is the server IP 
	and 'Port' is the player assigned port 
	
if the shell script does not work. from the current directory, in a shell
do:
	'$python connect_to_dealer.py IP Port'
		where 'IP' is the server IP 
		and 'Port' is the player assigned port
	
