#!/bin/bash
./example_player holdem.nolimit.2p.reverse_blinds.game $1 $2
