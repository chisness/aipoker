#!/bin/bash
./example_player holdem.limit.3p.game $1 $2
