#!/bin/bash
ACPC_DIR=./acpc_infrastructure
$ACPC_DIR/example_player $ACPC_DIR/holdem.limit.2p.reverse_blinds.game $1 $2
