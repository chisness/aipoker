python2 ../kuhn3p/players/Thief/kuhn3p-master/connect_to_dealer.py $1 $2 
