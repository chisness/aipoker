python2 ../kuhn3p/players/EFS/connect_to_dealer.py $1 $2 
