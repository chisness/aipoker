../kuhn3p/players/Juan/agent_player ./kuhn.limit.3p.game $1 $2 
