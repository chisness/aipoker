python2 ../kuhn3p/players/AgentSouth/connect_to_dealer.py $1 $2 
