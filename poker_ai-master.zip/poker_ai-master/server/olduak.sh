python2 ../connect_old_uak.py $1 $2
