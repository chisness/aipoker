python2 ../connect_to_dealer2.py $1 $2
