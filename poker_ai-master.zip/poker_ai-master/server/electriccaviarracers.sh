../kuhn3p/players/ElectricCaviarRacers/electric_caviar ./kuhn.limit.3p.game $1 $2 
