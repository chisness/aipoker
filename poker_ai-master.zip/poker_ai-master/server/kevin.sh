python2 ../kuhn3p/players/Kevin/src/connect_to_dealer.py $1 $2 
