fork from https://github.com/dennybritz/reinforcement-learning/tree/master/DQN
modified for kuhn poker