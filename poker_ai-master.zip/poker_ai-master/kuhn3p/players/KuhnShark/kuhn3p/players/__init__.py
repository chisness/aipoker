from .Bluffer import Bluffer
from .Chump import Chump
from .Shark import Shark
