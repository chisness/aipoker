#!/bin/bash
# $1 - The ip address of the dealer
# $2 - The port assigned to this player
/usr/bin/python2.7 connect_to_dealer.py $1 $2
