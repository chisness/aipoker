#!/bin/bash
../../project_acpc_server/agent_player ../../project_acpc_server/kuhn.limit.3p.game $1 $2
