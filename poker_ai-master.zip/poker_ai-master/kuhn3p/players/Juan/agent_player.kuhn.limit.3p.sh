#!/bin/bash
./agent_player kuhn.limit.3p.game $1 $2
