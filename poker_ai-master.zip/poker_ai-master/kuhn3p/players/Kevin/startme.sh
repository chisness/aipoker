#!/bin/bash
./src/connect_to_dealer.py $1 $2
