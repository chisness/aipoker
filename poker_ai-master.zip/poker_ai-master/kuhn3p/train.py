from kuhn3p import deck, dealer, players

players.UltimateAiKhun()